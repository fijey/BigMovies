package com.fjrapp.bigmovies;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.preference.Preference;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Switch;

import com.fjrapp.bigmovies.notification.DailyAppReminder;
import com.fjrapp.bigmovies.notification.DailyReleaseReminder;
import com.fjrapp.bigmovies.notification.ReminderPreferences;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnCheckedChanged;
import butterknife.OnClick;

import static com.fjrapp.bigmovies.Tool.KEY_DAILY_REMINDER;
import static com.fjrapp.bigmovies.Tool.KEY_HEADER_DAILY_REMINDER;
import static com.fjrapp.bigmovies.Tool.KEY_HEADER_UPCOMING_REMINDER;
import static com.fjrapp.bigmovies.Tool.KEY_UPCOMING_REMINDER;
import static com.fjrapp.bigmovies.notification.DailyAppReminder.TYPE_ONE_TIME;

public class SettingActivity extends AppCompatActivity {
    @BindView(R.id.dailyReminder)
    Switch dailyReminder;
    @BindView(R.id.relaseReminder)
    Switch releaseReminder;

    public DailyAppReminder dailyAppReminder;
    public DailyReleaseReminder dailyReleaseReminder;
    public ReminderPreferences reminderPreferences;
    public SharedPreferences prefReleaseReminder, prefDailyReminder;
    public SharedPreferences.Editor editorReleaseReminder, editorDailyReminder;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        ButterKnife.bind(this);
        dailyAppReminder = new DailyAppReminder();
        dailyReleaseReminder = new DailyReleaseReminder();
        reminderPreferences = new ReminderPreferences(this);
        setPreference();

    }

    @OnClick({R.id.text_language})
    public void onViewClicked (View view) {
        Intent intent = new Intent(Settings.ACTION_LOCALE_SETTINGS);
        startActivity(intent);
    }

    @OnCheckedChanged(R.id.dailyReminder)
    public void setDailyReminder(boolean isChecked) {
        editorDailyReminder = prefDailyReminder.edit();
        if (isChecked) {
            editorDailyReminder.putBoolean(KEY_DAILY_REMINDER,true);
            editorDailyReminder.commit();
            setDailyReminder();
        } else {
            editorDailyReminder.putBoolean(KEY_DAILY_REMINDER,false);
            editorDailyReminder.commit();
            cancelDailyReminder();

        }
    }

    @OnCheckedChanged(R.id.relaseReminder)
    public void setReleaseReminder(boolean isChecked) {
        editorReleaseReminder = prefReleaseReminder.edit();
        if (isChecked) {
           editorReleaseReminder.putBoolean(KEY_UPCOMING_REMINDER,true);
            editorReleaseReminder.commit();
            setReleaseReminderOn();
        } else {
            editorReleaseReminder.putBoolean(KEY_UPCOMING_REMINDER,false);
            editorReleaseReminder.commit();
            cancelReleaseReminder();

        }
    }

    private void setReleaseReminderOn() {
        String time ="07:00";
        String message = "";
        reminderPreferences.setReminderReleaseTime(time);
        reminderPreferences.setReminderReleaseMessage(message);
        dailyReleaseReminder.setReminder(SettingActivity.this, TYPE_ONE_TIME, time,message);
    }

    private void cancelReleaseReminder() {
        dailyReleaseReminder.cancelReminder(SettingActivity.this);
    }



    private void setPreference() {
        prefDailyReminder= getSharedPreferences(KEY_HEADER_DAILY_REMINDER, MODE_PRIVATE);
        prefReleaseReminder = getSharedPreferences(KEY_HEADER_UPCOMING_REMINDER,MODE_PRIVATE);
        boolean checkSwDailyReminder = prefDailyReminder.getBoolean(KEY_DAILY_REMINDER, false);
        dailyReminder.setChecked(checkSwDailyReminder);
        boolean checkSwReleaseReminder = prefReleaseReminder.getBoolean(KEY_UPCOMING_REMINDER, false);
        releaseReminder.setChecked(checkSwReleaseReminder);

    }
    private void setDailyReminder() {
        String time = "08:00";
        String message = getString(R.string.daily_text);
        reminderPreferences.setReminderDailyTime(time);
        reminderPreferences.setReminderDailyMessage(message);
        dailyAppReminder.setOneTimeAlarm(SettingActivity.this, TYPE_ONE_TIME,time,message);
    }
    private void cancelDailyReminder() {
        dailyAppReminder.cancelNotification(SettingActivity.this);
    }
}
