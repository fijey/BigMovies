package com.fjrapp.bigmovies;

public class Tool {
    public static final String API_KEY = "2eef7f621d0b892c273a8a26785b783d";
    public static final String BASE_URL = "https://api.themoviedb.org/3/";
    public static final String LANGUAGE = "en-US";
    public static final String KEY_DAILY_REMINDER = "checkedDaily";
    public static final String KEY_UPCOMING_REMINDER = "upcomingDaily";
    public static final String KEY_HEADER_UPCOMING_REMINDER = "upcomingReminder";
    public static final String KEY_HEADER_DAILY_REMINDER = "dailyReminder";
    public static final String AUTHORITY = "com.fjrapp.bigmovies";
    public static final String EXTRA_NAME = "name";
    public static final String URL = "https://image.tmdb.org/t/p/w185";

}
